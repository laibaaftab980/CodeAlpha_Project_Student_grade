// import java.util.Scanner;
import java.util.ArrayList;
import java.util.Scanner;
class Student{
    String Std_name;
    int grade;

    public Student(String name,int grade){
        this.Std_name=name;
        this.grade= grade;

    }
    public String getName(){
     return Std_name;
    }

    public int getGrade(){
        return grade;
       }

}

class Grade_manage{
    private ArrayList<Student> students;

     public Grade_manage(){
         students = new ArrayList<Student>();
     }

     public void add_Student(String Std_name, int grade){
        Student student = new Student(Std_name, grade);
        students.add(student);
     }
     public double calculate_avereage(){
        if(students.isEmpty()){
            return 0;
        }
        int sum = 0;
        for(Student student: students){
            sum += student.getGrade();
        }
        return (double) sum/students.size(); 
     }

     public int highest(){
        if(students.isEmpty()){
            return 0;
        }
        int highest = students.get(0).getGrade();
        for(Student student: students){
            if(student.getGrade()> highest){
                highest = student.getGrade();

            }
        }
        return highest; 
     }
     public int lowest(){
        if(students.isEmpty()){
            return 0;
        }
        int lowest = students.get(0).getGrade();
        for(Student student: students){
            if(student.getGrade()<lowest){
                lowest = student.getGrade();

            }
        }
        return lowest; 
     }
     public int size(){
        int size = students.size();
        return size;
     }
}

public class Main{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Scanner in = new Scanner(System.in);
        Grade_manage grade_mngr = new Grade_manage();

        System.out.println("********************************Student's Grade Tracker**************************");
        while (true) {
            System.out.println("***********Enter student name (or type done to finish)***************");
            String name = sc.nextLine();
            if(name.equalsIgnoreCase("done")){
                break;
            }
            System.out.println(" Enter Grade of "+ name );
            int grade = in.nextInt();
            sc.nextLine();
            
            grade_mngr.add_Student(name, grade);
        }
       // sc.close();
        while (true) {
        System.out.println("*********** Enter Your Choice **********");
        System.out.println(" 1-Total Students  ");
        System.out.println(" 2-Average Marks");
        System.out.println(" 3-Highest Marks ");
        System.out.println(" 4-Lowest Marks");
        System.out.println(" 5-Exit");
        int choice = in.nextInt();       
        
         switch (choice) {
             case 1:
             System.out.println("******* Total no Students in Class are " +grade_mngr.size() );
                 break;
             case 2:
             System.out.println("******* Average of Class is " +grade_mngr.calculate_avereage());
                 break;
             case 3:
             System.out.println("******* Highest marks of Class is " +grade_mngr.highest());
                 break; 
             case 4:
             System.out.println("******* Lowest marks of Class is " +grade_mngr.lowest());
        
                 break;      
             case 5:
             System.out.println("Exiting the porgram....!!!");
             System.out.println("**************** END *****************");
             sc.close();
             in.close();
             return;       
             default:
             System.out.println("Invalid choice,Please enter a correct otpion");
                 break;
         }
         
        }
        // System.out.println("*** Total no Studnets in Class are *** " +grade_mngr.size() + " ***");
        // System.out.println("*** Average of Class is *** " +grade_mngr.calculate_avereage()+" ***");
        // System.out.println("*** Highest marks of Class is *** " +grade_mngr.highest()+" ***");
        // System.out.println("*** Lowest marks of Class is *** " +grade_mngr.lowest()+" ***");

        
        
        //System.out.println("******************************END******************************");


    }
}